import dotenv from 'dotenv';
dotenv.config({ path: './.env' });

// Import email functions
import { 
  initializeEmailService, 
  testEmailConnection,
  sendOtpEmail,
  sendBookingConfirmation,
  sendWelcomeEmail
} from './src/utils/email.js';

// 🔧 Hardcoded Configuration Fallback
const HARDCODED_CONFIG = {
  GMAIL_USER: 'logigo5050@gmail.com',
  GMAIL_APP_PASSWORD: 'irst tsdw ikdn qhbg',
  PORT: 5600,
  MONGODB_URI: 'mongodb://localhost:27017/logigo'
};

// 🔧 Debug Environment Variables
console.log('🔧 Environment Variables Check:');
console.log('GMAIL_USER:', process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER || '❌ NOT LOADED');
console.log('GMAIL_APP_PASSWORD:', (process.env.GMAIL_APP_PASSWORD || HARDCODED_CONFIG.GMAIL_APP_PASSWORD) ? '✅ LOADED' : '❌ NOT LOADED');
console.log('PORT:', process.env.PORT || HARDCODED_CONFIG.PORT || '❌ NOT LOADED');
console.log('MONGODB_URI:', (process.env.MONGODB_URI || HARDCODED_CONFIG.MONGODB_URI) ? '✅ LOADED' : '❌ NOT LOADED');
console.log('-------------------');
console.log('JWT_SECRET:', process.env.JWT_SECRET ? '✅ LOADED' : '❌ NOT LOADED');


import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import crypto from "crypto";

// Import your existing routes
import authRoutes from "./src/routes/auth.routes.js";
import bookingRoutes from "./src/routes/booking.routes.js";
import paymentRoutes from './src/routes/payment.routes.js';
import adminRoutes from './src/routes/admin.routes.js';
import adminDashboardRoutes from "./src/routes/adminDashboard.routes.js";
import contactRoutes from "./src/routes/contact.routes.js";
import userDashboardRoutes from "./src/routes/userDashboard.routes.js";





const app = express();

// 🔐 Security + logging middleware
app.use(helmet());
app.use(morgan("dev"));
app.use(express.json());
app.use(cors({
  origin: process.env.CORS_ORIGIN || "*",
  methods: ["GET", "POST", "PUT", "DELETE", "PATCH"],
  credentials: true
}));

// Rate limiting
import rateLimit from 'express-rate-limit';
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  message: { error: 'Too many requests, please try again later' }
});
app.use('/api/', limiter);

// 🗄️ Database connection with fallback
const mongoUri = process.env.MONGODB_URI || HARDCODED_CONFIG.MONGODB_URI || "mongodb://127.0.0.1:27017/logigo";
console.log("🔗 Connecting to MongoDB:", mongoUri);

mongoose.connect(mongoUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(async () => {
  console.log("✅ MongoDB Connected Successfully");
  console.log("📊 Database Name:", mongoose.connection.name);
  console.log("🔌 Connection State:", mongoose.connection.readyState);
  
  // Initialize email service after DB connection
  const emailInitialized = await initializeEmailService();
  if (emailInitialized) {
    console.log('✅ Email service initialized successfully');
    
    // Test email connection
    const emailConnected = await testEmailConnection();
    if (emailConnected) {
      console.log('✅ Email service connected successfully');
    } else {
      console.warn('⚠️ Email service connection failed');
    }
  } else {
    console.warn('⚠️ Email service initialization failed');
  }
}).catch(err => {
  console.error("❌ MongoDB Error:", err.message);
  process.exit(1);
});

// OTP storage (production में Redis/Database use करें)
global.otpStore = new Map();

// Payment storage (temporary storage for demo)
global.paymentStore = new Map();

// Helper function to generate OTP
function generateOTP() {
  return crypto.randomInt(100000, 999999).toString();
}

// Helper function to generate payment ID
function generatePaymentId() {
  return 'PAY' + crypto.randomInt(100000, 999999).toString();
}

// Helper function to generate UTR
function generateUTR() {
  return 'UTR' + crypto.randomInt(100000000, 999999999).toString();
}

// Default route
app.get("/", (req, res) => {
  const gmailUser = process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER;
  const gmailPassword = process.env.GMAIL_APP_PASSWORD || HARDCODED_CONFIG.GMAIL_APP_PASSWORD;
  
  res.json({
    message: "🚀 Logigo Backend API is running!",
    environment: {
      nodeEnv: process.env.NODE_ENV || 'development',
      gmailConfig: {
        user: gmailUser ? '✅ Configured' : '❌ Missing',
        appPassword: gmailPassword ? '✅ Configured' : '❌ Missing'
      }
    }
  });
});

// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "OK",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    database: mongoose.connection.readyState === 1 ? 'Connected' : 'Disconnected',
    otpStoreSize: global.otpStore.size,
    paymentStoreSize: global.paymentStore.size
  });
});

// API info endpoint
app.get('/api', (req, res) => {
  res.json({ 
    message: 'API is working!', 
    endpoints: {
      'POST /api/auth/send-otp': 'Send OTP to email',
      'POST /api/auth/verify-otp': 'Verify OTP',
      'POST /api/auth/signup': 'User registration',
      'POST /api/auth/login': 'User login',
      'GET /api/payment/booking/:bookingId': 'Get booking details for payment',
      'POST /api/payment/initiate': 'Initiate payment',
      'GET /api/payment/status/:paymentId': 'Check payment status',
      'POST /api/payments': 'Save payment to MongoDB',
      'GET /api/payments/:paymentId': 'Get payment from MongoDB'
    }
  });
});

// Handle OPTIONS requests
app.options('/api/auth/*', (req, res) => {
  res.status(204).send();
});

// Send OTP endpoint (using email.js function)
app.post('/api/auth/send-otp', async (req, res) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    // Generate OTP
    const otp = generateOTP();
    const timestamp = Date.now();

    // Store OTP with 5-minute expiry
    global.otpStore.set(email, {
      otp: otp,
      timestamp: timestamp,
      verified: false
    });

    // Auto-delete OTP after 5 minutes
    setTimeout(() => {
      global.otpStore.delete(email);
    }, 5 * 60 * 1000);

    console.log(`🔐 OTP for ${email}: ${otp}`);
    
    // Use email.js function to send OTP
    const emailSent = await sendOtpEmail(email, otp);
    
    if (emailSent) {
      res.json({ 
        success: true, 
        message: 'OTP sent successfully',
        development: true,
        otp: otp // Only for development
      });
    } else {
      res.status(500).json({ error: 'Failed to send email' });
    }

  } catch (error) {
    console.error('Send OTP error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Verify OTP endpoint
app.post('/api/auth/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;

    if (!email || !otp) {
      return res.status(400).json({ error: 'Email and OTP are required' });
    }

    // Get stored OTP
    const storedOtpData = global.otpStore.get(email);

    if (!storedOtpData) {
      return res.status(400).json({ error: 'OTP not found or expired' });
    }

    // Check if OTP is expired (5 minutes)
    const now = Date.now();
    const otpAge = now - storedOtpData.timestamp;
    const maxAge = 5 * 60 * 1000; // 5 minutes

    if (otpAge > maxAge) {
      global.otpStore.delete(email);
      return res.status(400).json({ error: 'OTP has expired' });
    }

    // Verify OTP
    if (storedOtpData.otp !== otp) {
      return res.status(400).json({ error: 'Invalid OTP' });
    }

    // Mark as verified
    storedOtpData.verified = true;
    global.otpStore.set(email, storedOtpData);

    res.json({ 
      success: true, 
      message: 'OTP verified successfully'
    });

  } catch (error) {
    console.error('Verify OTP error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Get booking details for payment
app.get('/api/payment/booking/:bookingId', async (req, res) => {
  try {
    const { bookingId } = req.params;
    
    // In a real application, you would fetch this from your database
    // For demo purposes, we'll return mock data
    const bookingDetails = {
      bookingId: bookingId,
      amount: 1500,
      vehicleName: 'Selected Vehicle',
      vehicleDetails: { name: 'Selected Vehicle' },
      bookingDetails: {}
    };
    
    res.json({
      success: true,
      data: bookingDetails
    });
  } catch (error) {
    console.error('Error fetching booking details:', error);
    res.status(500).json({ error: 'Failed to fetch booking details' });
  }
});

// Initiate payment endpoint
app.post('/api/payment/initiate', async (req, res) => {
  try {
    const { bookingId, paymentMethod, paymentDetails } = req.body;
    
    if (!bookingId || !paymentMethod) {
      return res.status(400).json({ error: 'Booking ID and payment method are required' });
    }
    
    // Generate payment ID and UTR
    const paymentId = generatePaymentId();
    const utrNumber = generateUTR();
    
    // Store payment details
    global.paymentStore.set(paymentId, {
      bookingId,
      paymentMethod,
      paymentDetails,
      status: 'PENDING',
      amount: 1500, // In real app, fetch from booking
      createdAt: new Date(),
      utrNumber
    });
    
    // Simulate payment processing
    setTimeout(() => {
      // 85% success rate for demo
      const success = Math.random() > 0.15;
      
      const paymentData = global.paymentStore.get(paymentId);
      if (paymentData) {
        paymentData.status = success ? 'SUCCESS' : 'FAILED';
        paymentData.updatedAt = new Date();
        if (!success) {
          paymentData.failureReason = 'Payment declined by bank';
        }
        global.paymentStore.set(paymentId, paymentData);
      }
    }, 5000); // Process after 5 seconds
    
    res.json({
      success: true,
      data: {
        paymentId,
        message: 'Payment initiated successfully'
      }
    });
  } catch (error) {
    console.error('Payment initiation error:', error);
    res.status(500).json({ error: 'Failed to initiate payment' });
  }
});

// Check payment status
app.get('/api/payments/status/:paymentId', async (req, res) => {
  try {
    const { paymentId } = req.params;
    
    const paymentData = global.paymentStore.get(paymentId);
    
    if (!paymentData) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    res.json({
      success: true,
      data: paymentData
    });
  } catch (error) {
    console.error('Payment status check error:', error);
    res.status(500).json({ error: 'Failed to check payment status' });
  }
});

// Send booking confirmation email endpoint
app.post('/api/booking/confirmation-email', async (req, res) => {
  try {
    const { email, bookingDetails } = req.body;
    
    if (!email || !bookingDetails) {
      return res.status(400).json({ error: 'Email and booking details are required' });
    }
    
    await sendBookingConfirmation(email, bookingDetails);
    
    res.json({
      success: true,
      message: 'Booking confirmation email sent successfully'
    });
  } catch (error) {
    console.error('Booking confirmation email error:', error);
    res.status(500).json({ error: 'Failed to send booking confirmation email' });
  }
});

// Send welcome email endpoint
app.post('/api/welcome-email', async (req, res) => {
  try {
    const { email, name } = req.body;
    
    if (!email || !name) {
      return res.status(400).json({ error: 'Email and name are required' });
    }
    
    await sendWelcomeEmail(email, name);
    
    res.json({
      success: true,
      message: 'Welcome email sent successfully'
    });
  } catch (error) {
    console.error('Welcome email error:', error);
    res.status(500).json({ error: 'Failed to send welcome email' });
  }
});

// 📌 Your existing routes (these will handle MongoDB operations)
app.use("/api/auth", authRoutes);
app.use("/api/bookings", bookingRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api", adminDashboardRoutes);
app.use("/api/contact", contactRoutes);
app.use("/api/userDashboard", userDashboardRoutes);



// Error handling middleware
app.use((err, req, res, next) => {
  console.error('🔥 Global Error:', err);
  res.status(500).json({
    success: false,
    message: "Something went wrong!",
    error: process.env.NODE_ENV === "development" ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "❌ Route not found",
  });
});

// Start server with fallback port
const PORT = process.env.PORT || HARDCODED_CONFIG.PORT || 5600;
app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
  console.log(`🔍 Environment status: http://localhost:${PORT}/`);
  console.log(`❤️ Health check: http://localhost:${PORT}/api/health`);
  console.log(`🔗 API Base URL: http://localhost:${PORT}/api`);
  
  console.log('\n📋 Available endpoints:');
  console.log('   GET  /                      - Health check');
  console.log('   GET  /api                   - API info');
  console.log('   POST /api/auth/send-otp     - Send OTP');
  console.log('   POST /api/auth/verify-otp   - Verify OTP');
  console.log('   POST /api/auth/signup       - User registration');
  console.log('   POST /api/auth/login        - User login');
  console.log('   GET  /api/payment/booking/:bookingId - Get booking details');
  console.log('   POST /api/payment/initiate  - Initiate payment');
  console.log('   GET  /api/payment/status/:paymentId  - Check payment status');
  console.log('   POST /api/booking/confirmation-email - Send booking confirmation email');
  console.log('   POST /api/welcome-email     - Send welcome email');
  console.log('   POST /api/payments          - Save payment to MongoDB');
  console.log('   GET  /api/payments/:paymentId - Get payment from MongoDB');
  
  // Show which config is being used
  if (!process.env.GMAIL_USER && HARDCODED_CONFIG.GMAIL_USER) {
    console.log('⚠️ Using hardcoded Gmail configuration');
  }
  if (!process.env.MONGODB_URI && HARDCODED_CONFIG.MONGODB_URI) {
    console.log('⚠️ Using hardcoded MongoDB configuration');
  }
});