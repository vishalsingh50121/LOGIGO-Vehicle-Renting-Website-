// routes/userDashboard.routes.js - FIXED VERSION
import express from "express";
import User from "../models/User.js";
import Booking from "../models/Booking.js";
import Payment from "../models/Payment.js";

const router = express.Router();

// GET PAYMENTS - COMPLETELY FIXED VERSION
router.get("/payments/:email", async (req, res) => {
    try {
        const { email } = req.params;
        
        console.log("💰 Fetching payments for email:", email);
        
        // Method 1: Direct query with case-insensitive search
        const payments = await Payment.find({
            userEmail: { $regex: new RegExp(email, "i") }
        })
        .select('paymentId bookingId amount paymentMethod vehicleName timestamp status transactionId utrNumber refundStatus refundDate userEmail userName')
        .sort({ timestamp: -1 })
        .lean(); // Use lean() for better performance

        console.log(`💰 Found ${payments.length} payments directly for email: ${email}`);
        
        // If no payments found, let's debug further
        if (payments.length === 0) {
            console.log("🔍 No payments found. Checking database...");
            
            // Check if any payments exist in the database
            const totalPayments = await Payment.countDocuments();
            console.log(`📊 Total payments in database: ${totalPayments}`);
            
            // Check a sample of payments to see their structure
            const samplePayments = await Payment.find().limit(3).lean();
            console.log("📝 Sample payments structure:", samplePayments.map(p => ({
                paymentId: p.paymentId,
                userEmail: p.userEmail,
                bookingId: p.bookingId
            })));
            
            // Check if there are payments with similar emails
            const emailDomain = email.split('@')[1];
            const similarPayments = await Payment.find({
                userEmail: { $regex: emailDomain, $options: 'i' }
            }).limit(3).lean();
            
            console.log(`🔍 Found ${similarPayments.length} payments with similar email domain`);
        }

        res.json({ 
            success: true, 
            payments: payments,
            count: payments.length
        });

    } catch (error) {
        console.error("❌ Payments fetch error:", error);
        res.status(500).json({ 
            success: false, 
            message: "Server error",
            error: error.message 
        });
    }
});

// GET USER PROFILE
router.get("/profile/:email", async (req, res) => {
    try {
        const { email } = req.params;
        const user = await User.findOne({
            email: { $regex: new RegExp(`^${email}$`, "i") },
        });

        if (!user) {
            return res.status(404).json({ 
                success: false, 
                message: "User not found" 
            });
        }

        res.json({ success: true, user });

    } catch (error) {
        console.error("Profile fetch error:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

// GET BOOKINGS
router.get("/bookings/:email", async (req, res) => {
    try {
        const { email } = req.params;
        const bookings = await Booking.find({
            "customer.email": { $regex: new RegExp(`^${email}$`, "i") },
        }).sort({ createdAt: -1 });

        res.json({ success: true, bookings });

    } catch (error) {
        console.error("Bookings fetch error:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});

export default router;