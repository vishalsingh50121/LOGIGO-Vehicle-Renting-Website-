import express from "express";
import bcrypt from "bcryptjs";
import User from "../models/User.js";
import nodemailer from "nodemailer";
import crypto from "crypto";
import mongoose from "mongoose";
import { sendOtpEmail } from "../utils/email.js";
import jwt from "jsonwebtoken";

const router = express.Router();

// Initialize OTP store if not exists
if (!global.otpStore) {
  global.otpStore = new Map();
  console.log("✅ Initialized OTP store");
}

// Signup Route with OTP Verification - DEBUG VERSION
router.post("/signup", async (req, res) => {
  try {
    console.log("=== SIGNUP REQUEST ===");
    console.log("Request body:", req.body);
    
    const { name, email, phone, dob, address, password, otp } = req.body;

    // Check MongoDB connection
    console.log("📊 MongoDB Connection State:", mongoose.connection.readyState);
    if (mongoose.connection.readyState !== 1) {
      return res.status(500).json({ error: "Database not connected" });
    }

    // Check if OTP is provided and valid
    if (!otp) {
      console.log("❌ OTP missing in request");
      return res.status(400).json({ error: "OTP is required for signup" });
    }

    // Verify OTP
    console.log("🔍 Checking OTP for email:", email);
    const storedOtpData = global.otpStore.get(email);
    
    if (!storedOtpData) {
      console.log("❌ OTP not found for email:", email);
      return res.status(400).json({ error: "OTP not found or expired. Please request a new OTP." });
    }

    if (storedOtpData.otp !== otp) {
      console.log("❌ Invalid OTP provided:", otp, "Expected:", storedOtpData.otp);
      return res.status(400).json({ error: "Invalid OTP" });
    }

    console.log("✅ OTP verified successfully");

    // Check if user already exists
    console.log("🔍 Checking if user exists with email:", email);
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.log("❌ User already exists with email:", email);
      return res.status(400).json({ error: "Email already registered" });
    }

    // Hash password
    console.log("🔒 Hashing password...");
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // Create new user
    console.log("👤 Creating new user...");
    const newUser = new User({
      name,
      email,
      phone,
      dob: new Date(dob),
      address,
      password: hashedPassword,
      emailVerified: true
    });

    console.log("📋 User object created:", newUser);
    
    // Save user to database
    console.log("💾 Saving user to database...");
    const savedUser = await newUser.save();
    console.log("✅ User saved successfully with ID:", savedUser._id);

    // Remove OTP after successful signup
    global.otpStore.delete(email);
    console.log("🗑️ OTP removed from store");

    // Verify the user was actually saved
    const verifyUser = await User.findById(savedUser._id);
    console.log("🔍 Verification - User found in DB:", verifyUser ? "YES" : "NO");

    res.status(201).json({ 
      message: "User registered successfully ✅",
      user: {
        id: savedUser._id,
        name: savedUser.name,
        email: savedUser.email
      }
    });

  } catch (error) {
    console.error("🔥 SIGNUP ERROR DETAILS:", error);
    
    // MongoDB duplicate key error
    if (error.code === 11000) {
      return res.status(400).json({ error: "Email already registered" });
    }
    
    // Validation errors
    if (error.name === 'ValidationError') {
      const errors = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({ error: errors.join(', ') });
    }
    
    res.status(500).json({ error: "Server error during signup: " + error.message });
  }
});

/* ------------------ FORGOT PASSWORD (Send OTP) ------------------ */
router.post("/forgot-password", async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // OTP generate
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // OTP save with expiry
    user.resetOTP = otp;
    user.resetOTPExpiry = Date.now() + 5 * 60 * 1000; // 5 minutes
    await user.save();

    // Send OTP
    await sendOtpEmail(user.email, otp);

    res.json({ message: "OTP sent to your email" });
  } catch (error) {
    console.error("Forgot password error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

/* ------------------ RESET PASSWORD ------------------ */
router.post("/reset-password", async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    const user = await User.findOne({ email });

    if (!user) return res.status(404).json({ message: "User not found" });
    if (!user.resetOTP || !user.resetOTPExpiry) {
      return res.status(400).json({ message: "No OTP request found" });
    }

    // OTP check
    if (user.resetOTP !== otp) {
      return res.status(400).json({ message: "Invalid OTP" });
    }
    if (user.resetOTPExpiry < Date.now()) {
      return res.status(400).json({ message: "OTP expired" });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;

    // Clear OTP fields
    user.resetOTP = null;
    user.resetOTPExpiry = null;
    await user.save();

    res.json({ message: "Password reset successful" });
  } catch (error) {
    console.error("Reset password error:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Test MongoDB connection endpoint
router.get("/test-db", async (req, res) => {
  try {
    const dbState = mongoose.connection.readyState;
    let stateMessage = "";
    
    switch(dbState) {
      case 0: stateMessage = "disconnected"; break;
      case 1: stateMessage = "connected"; break;
      case 2: stateMessage = "connecting"; break;
      case 3: stateMessage = "disconnecting"; break;
      default: stateMessage = "unknown";
    }
    
    // Try to perform a simple DB operation
    const usersCount = await User.countDocuments();
    
    res.json({
      database: {
        state: dbState,
        status: stateMessage,
        name: mongoose.connection.name,
        usersCount: usersCount
      }
    });
  } catch (error) {
    res.status(500).json({ error: "DB test failed: " + error.message });
  }
});

/* ------------------ LOGIN ROUTE ------------------ */
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    // Find user
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ message: "Invalid email or password" });

    // Optional: check email verification
    if (!user.emailVerified) {
      return res.status(403).json({ message: "Email not verified" });
    }

    // Generate JWT token (expires in 1 day)
  const token = jwt.sign(
  { id: user._id, email: user.email },
  process.env.JWT_SECRET || "defaultSecretKey",  // fallback bhi isi line me
  { expiresIn: "1d" }
);


    res.json({
      message: "Login successful ✅",
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });

  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error during login" });
  }
});

export default router;