// src/routes/contact.routes.js
import express from "express";
import Contact from "../models/contact.model.js";


const router = express.Router();

// POST /api/contact
router.post("/", async (req, res) => {
  try {
    const { name, email, subject, message } = req.body;

    if (!name || !email || !subject || !message) {
      return res.status(400).json({ success: false, message: "All fields are required" });
    }

    // Save contact message to MongoDB
    const newMessage = new Contact({ name, email, subject, message });
    await newMessage.save();

    // ✅ Optional: Send notification email to admin
    // await sendOtpEmail('logigo5050@gmail.com', `New contact from ${name}\n\n${message}`);

    res.json({ success: true, message: "Message received successfully" });
  } catch (error) {
    console.error("Contact form error:", error);
    res.status(500).json({ success: false, message: "Failed to submit contact form" });
  }
});

export default router;
