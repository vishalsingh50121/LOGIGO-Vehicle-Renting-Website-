// src/routes/booking.js
import express from 'express';
import Booking from '../models/Booking.js';
import { validateBooking } from '../middleware/bookingMiddleware.js';
import { sendBookingNotification } from '../utils/email.js';
import { bookingApprovedTemplate, bookingCancelledTemplate } from '../utils/emailTemplates.js';

const router = express.Router();

// ✅ Create new booking
router.post('/', validateBooking, async (req, res) => {
  try {
    const {
      bookingId,
      vehicleId,
      vehicleName,
      ratePerDay,
      days,
      total,
      customer,
      trip,
      paymentMethod,
      notes
    } = req.body;

    const newBooking = new Booking({
      bookingId: bookingId || 'BK' + Date.now(),
      vehicleId,
      vehicleName,
      ratePerDay,
      days,
      total,
      customer,
      trip: {
        pickupLocation: trip.pickupLocation,
        dropoffLocation: trip.dropoffLocation,
        pickupDT: new Date(trip.pickupDT),
        dropoffDT: new Date(trip.dropoffDT)
      },
      paymentMethod,
      notes: notes || '',
      status: 'confirmed' // lowercase should match schema enum
    });

    const savedBooking = await newBooking.save();

    // ✅ Optional: Send booking created email (if needed)
    // const emailTemplate = bookingApprovedTemplate(
    //   customer.fullName,
    //   vehicleName,
    //   savedBooking.bookingId,
    //   trip.pickupDT,
    //   days
    // );
    // await sendBookingNotification(customer.email, 'Booking Confirmed - Logigo', emailTemplate);

    res.status(201).json({
      success: true,
      message: 'Booking created successfully',
      booking: savedBooking
    });
  } catch (error) {
    console.error('Booking creation error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to create booking',
      error: error.message
    });
  }
});

// ✅ Get all bookings for a specific user by email
router.get('/user/:email', async (req, res) => {
  try {
    const { email } = req.params;
    const bookings = await Booking.find({ 'customer.email': email }).sort({ createdAt: -1 });

    res.json({
      success: true,
      count: bookings.length,
      bookings
    });
  } catch (error) {
    console.error('Get user bookings error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch user bookings',
      error: error.message
    });
  }
});

// ✅ Get booking by bookingId
router.get('/:bookingId', async (req, res) => {
  try {
    const booking = await Booking.findOne({ bookingId: req.params.bookingId });
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });
    res.json({ success: true, booking });
  } catch (error) {
    console.error('Get booking error:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch booking', error: error.message });
  }
});

// ✅ Update booking status and send email notifications
router.patch('/:bookingId/status', async (req, res) => {
  try {
    const { status } = req.body;

    // Ensure lowercase to match schema enum
    const newStatus = status.toLowerCase();

    if (!['pending', 'confirmed', 'cancelled', 'completed'].includes(newStatus)) {
      return res.status(400).json({ success: false, message: 'Invalid status value' });
    }

    const booking = await Booking.findOneAndUpdate(
      { bookingId: req.params.bookingId },
      { status: newStatus, updatedAt: new Date() },
      { new: true, runValidators: true }
    );

    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

    // ✅ Send email based on status
    try {
      if (newStatus === 'confirmed') {
        const emailTemplate = bookingApprovedTemplate(
          booking.customer.fullName,
          booking.vehicleName,
          booking.bookingId,
          booking.trip.pickupDT,
          booking.days
        );
        await sendBookingNotification(
          booking.customer.email,
          'Your Booking Has Been Approved - Logigo',
          emailTemplate
        );
      } else if (newStatus === 'cancelled') {
        const emailTemplate = bookingCancelledTemplate(
          booking.customer.fullName,
          booking.vehicleName,
          booking.bookingId,
          booking.trip.pickupDT
        );
        await sendBookingNotification(
          booking.customer.email,
          'Your Booking Has Been Cancelled - Logigo',
          emailTemplate
        );
      }
    } catch (emailError) {
      console.error('Email sending error:', emailError);
    }

    res.json({ success: true, message: 'Booking status updated', booking });
  } catch (error) {
    console.error('Update booking error:', error);
    res.status(500).json({ success: false, message: 'Failed to update booking', error: error.message });
  }
});

export default router;
