// src/routes/payment_routes.js - COMPLETE FIXED VERSION
import express from 'express';
import Payment from '../models/Payment.js';
import { 
  validatePayment, 
  validatePaymentId, 
  initiatePayment,
  getPaymentStatus
} from "../middleware/payment.middleware.js";

const router = express.Router();

// POST /api/payments - Save payment to MongoDB - UPDATED
router.post('/', validatePayment, initiatePayment, async (req, res) => {
  try {
    const { 
      bookingId, 
      amount, 
      paymentMethod, 
      vehicleName, 
      timestamp, 
      userEmail,   
      userName,    
      utrNumber    
    } = req.body;
    
    console.log("📥 Received payment data:", req.body);
    
    // Generate a unique payment ID
    const paymentId = 'PAY' + Date.now().toString(36).toUpperCase() + 
                     Math.random().toString(36).substr(2, 4).toUpperCase();
    
    // ✅ Use the UTR from frontend or generate one
    const finalUtr = utrNumber || 'UTR' + Date.now().toString(36).toUpperCase() + 
                     Math.random().toString(36).substr(2, 6).toUpperCase();
    
    // Create new payment record
    const newPayment = new Payment({
      paymentId,
      bookingId,
      amount,
      paymentMethod,
      vehicleName,
      timestamp: new Date(timestamp),
      status: 'success', // ✅ Initial payment status
      transactionId: req.paymentGatewayResponse?.transactionId || paymentId,
      userEmail,    
      userName,     
      utrNumber: finalUtr
    });
    
    // Save to database
    await newPayment.save();
    
    console.log("✅ Payment saved successfully:", {
      paymentId: newPayment.paymentId,
      userEmail: newPayment.userEmail,
      bookingId: newPayment.bookingId,
      utrNumber: newPayment.utrNumber,
      status: newPayment.status
    });
    
    res.status(201).json({
      success: true,
      message: 'Payment stored successfully',
      paymentId: newPayment.paymentId,
      transactionId: newPayment.transactionId,
      utrNumber: newPayment.utrNumber
    });
  } catch (error) {
    console.error('❌ Error storing payment:', error);
    
    if (error.code === 11000) {
      return res.status(400).json({
        success: false,
        message: 'Duplicate payment ID or UTR number'
      });
    }
    
    res.status(500).json({
      success: false,
      message: 'Failed to store payment information',
      error: error.message
    });
  }
});

// GET /api/payments/:paymentId - Retrieve payment from MongoDB
router.get('/:paymentId', validatePaymentId, getPaymentStatus, async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      payment: req.paymentDetails
    });
  } catch (error) {
    console.error('Error fetching payment:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch payment information'
    });
  }
});

// GET /api/payments/status/:paymentId - Get detailed payment status
router.get('/status/:paymentId', validatePaymentId, getPaymentStatus, async (req, res) => {
  try {
    res.status(200).json({
      success: true,
      paymentId: req.params.paymentId,
      status: req.paymentDetails.status,
      lastChecked: new Date(),
      details: req.paymentDetails
    });
  } catch (error) {
    console.error('Error checking payment status:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to check payment status'
    });
  }
});

// ✅ FIXED: PATCH /api/payments/:paymentId/refund - Process refund
router.patch('/:paymentId/refund', validatePaymentId, getPaymentStatus, async (req, res) => {
  try {
    const { paymentId } = req.params;
    const payment = req.paymentDetails;
    
    console.log(`🔄 Processing refund for payment: ${paymentId}`);
    
    // Check if payment is already refunded
    if (payment.refundStatus === 'refunded') {
      return res.status(400).json({
        success: false,
        message: 'Payment has already been refunded'
      });
    }
    
    // Check if payment was successful
    if (payment.status !== 'success') {
      return res.status(400).json({
        success: false,
        message: 'Only successful payments can be refunded'
      });
    }
    
    // ✅ FIX: Update BOTH refundStatus AND main status
    payment.refundStatus = 'refunded';
    payment.status = 'refunded'; // ✅ IMPORTANT: Update main status too
    payment.refundDate = new Date();
    payment.refundId = 'REF' + Date.now().toString(36).toUpperCase();
    
    await payment.save();
    
    console.log("✅ Refund processed successfully:", {
      paymentId: payment.paymentId,
      refundStatus: payment.refundStatus,
      status: payment.status,
      refundId: payment.refundId
    });
    
    res.status(200).json({
      success: true,
      message: 'Payment refund processed successfully',
      refundId: payment.refundId,
      refundAmount: payment.amount,
      refundDate: payment.refundDate,
      status: payment.status // ✅ Send updated status
    });
    
  } catch (error) {
    console.error('❌ Error processing refund:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to process refund',
      error: error.message
    });
  }
});

// ✅ NEW: Update payment status when booking is cancelled
router.patch('/:paymentId/status', validatePaymentId, getPaymentStatus, async (req, res) => {
  try {
    const { paymentId } = req.params;
    const { status } = req.body;
    const payment = req.paymentDetails;
    
    console.log(`🔄 Updating payment status: ${paymentId} -> ${status}`);
    
    // Validate status
    const allowedStatuses = ['success', 'failed', 'refunded', 'pending'];
    if (!allowedStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: 'Invalid status. Allowed: success, failed, refunded, pending'
      });
    }
    
    // Update payment status
    payment.status = status;
    
    // If status is refunded, set refund fields
    if (status === 'refunded') {
      payment.refundStatus = 'refunded';
      payment.refundDate = new Date();
      payment.refundId = payment.refundId || 'REF' + Date.now().toString(36).toUpperCase();
    }
    
    await payment.save();
    
    console.log("✅ Payment status updated successfully:", {
      paymentId: payment.paymentId,
      newStatus: payment.status,
      refundStatus: payment.refundStatus
    });
    
    res.status(200).json({
      success: true,
      message: 'Payment status updated successfully',
      paymentId: payment.paymentId,
      status: payment.status,
      refundStatus: payment.refundStatus
    });
    
  } catch (error) {
    console.error('❌ Error updating payment status:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to update payment status',
      error: error.message
    });
  }
});

// ✅ NEW: Get payments by booking ID (for admin when cancelling booking)
router.get('/booking/:bookingId', async (req, res) => {
  try {
    const { bookingId } = req.params;
    
    console.log(`🔍 Fetching payment for booking: ${bookingId}`);
    
    const payment = await Payment.findOne({ bookingId });
    
    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'No payment found for this booking'
      });
    }
    
    res.status(200).json({
      success: true,
      payment: payment
    });
    
  } catch (error) {
    console.error('❌ Error fetching payment by booking ID:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch payment',
      error: error.message
    });
  }
});

export default router;