// src/utils/emailTemplates.js
export const bookingApprovedTemplate = (userName, vehicleName, bookingId, pickupDate, duration) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #4a6cf7; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
        .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 5px 5px; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
        .button { background: #4a6cf7; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Booking Approved</h1>
        </div>
        <div class="content">
          <h2>Hello ${userName},</h2>
          <p>Your booking has been <strong>approved</strong> by the administration team.</p>
          
          <h3>Booking Details:</h3>
          <ul>
            <li><strong>Booking ID:</strong> ${bookingId}</li>
            <li><strong>Vehicle:</strong> ${vehicleName}</li>
            <li><strong>Pickup Date:</strong> ${new Date(pickupDate).toLocaleDateString()}</li>
            <li><strong>Duration:</strong> ${duration} days</li>
          </ul>
          
          <p>Please ensure you arrive on time for your vehicle pickup. If you have any questions, contact our support team.</p>
          
          <p>Thank you for choosing Logigo!</p>
        </div>
        <div class="footer">
          <p>This is an automated message. Please do not reply to this email.</p>
          <p>&copy; ${new Date().getFullYear()} Logigo. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
};

export const bookingCancelledTemplate = (userName, vehicleName, bookingId, pickupDate) => {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #dc3545; color: white; padding: 20px; text-align: center; border-radius: 5px 5px 0 0; }
        .content { background: #f9f9f9; padding: 20px; border-radius: 0 0 5px 5px; }
        .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Booking Cancelled</h1>
        </div>
        <div class="content">
          <h2>Hello ${userName},</h2>
          <p>We regret to inform you that your booking has been <strong>cancelled</strong> by the administration team.</p>
          
          <h3>Booking Details:</h3>
          <ul>
            <li><strong>Booking ID:</strong> ${bookingId}</li>
            <li><strong>Vehicle:</strong> ${vehicleName}</li>
            <li><strong>Pickup Date:</strong> ${new Date(pickupDate).toLocaleDateString()}</li>
          </ul>
          
          <p>If you believe this is a mistake or have any questions, please contact our support team immediately.</p>
          
          <p>We apologize for any inconvenience caused.</p>
        </div>
        <div class="footer">
          <p>This is an automated message. Please do not reply to this email.</p>
          <p>&copy; ${new Date().getFullYear()} Logigo. All rights reserved.</p>
        </div>
      </div>
    </body>
    </html>
  `;
};



// अगर आपके existing exports हैं तो उन्हें भी named exports में बदलें
// export const yourExistingFunction = () => { ... };