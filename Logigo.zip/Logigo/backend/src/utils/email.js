// src/utils/email.js
import nodemailer from 'nodemailer';

// Hardcoded config as fallback
const HARDCODED_CONFIG = {
  GMAIL_USER: 'logigo5050@gmail.com',
  GMAIL_APP_PASSWORD: 'irst tsdw ikdn qhbg'
};

let emailTransport;

// Create Gmail transporter with fallback config
const createGmailTransport = () => {
  try {
    const gmailUser = process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER;
    const gmailPassword = process.env.GMAIL_APP_PASSWORD || HARDCODED_CONFIG.GMAIL_APP_PASSWORD;

    if (!gmailUser || !gmailPassword) {
      throw new Error('Gmail credentials not found');
    }

    const transport = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: gmailUser,
        pass: gmailPassword
      }
    });

    console.log('✅ Gmail transporter created successfully');
    return transport;
    
  } catch (error) {
    console.error('❌ Failed to create Gmail transporter:', error.message);
    return null;
  }
};

// Initialize email service on startup
export const initializeEmailService = async () => {
  console.log('🔧 Initializing email service...');
  
  try {
    emailTransport = createGmailTransport();
    
    if (!emailTransport) {
      return false;
    }

    // Verify connection configuration
    await emailTransport.verify();
    console.log('✅ Email server is ready to take our messages');
    return true;
  } catch (error) {
    console.error('❌ Email service initialization failed:', error);
    return false;
  }
};

// Test the transporter
export const testEmailConnection = async () => {
  if (!emailTransport) {
    return false;
  }

  try {
    await emailTransport.verify();
    console.log('✅ Gmail connection verified');
    return true;
  } catch (error) {
    console.error('❌ Gmail connection failed:', error.message);
    return false;
  }
};

// Check if email service is available
export const isEmailServiceAvailable = () => {
  return emailTransport !== null && emailTransport !== undefined;
};

// Send OTP email with attractive styling
export const sendOtpEmail = async (email, otp) => {
  if (!emailTransport) {
    console.error('Email transporter not initialized');
    return false;
  }

  try {
    await emailTransport.sendMail({
      from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
      to: email,
      subject: '🔐 Your OTP Code for Logigo - Secure Verification',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>OTP Verification</title>
        </head>
        <body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
          <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff;">
            <!-- Header -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px 30px; text-align: center;">
              <h1 style="color: #ffffff; margin: 0; font-size: 32px; font-weight: 700; letter-spacing: -0.5px;">
                🚚 LOGIGO
              </h1>
              <p style="color: #e2e8f0; margin: 8px 0 0 0; font-size: 16px; opacity: 0.9;">
                Secure Verification Code
              </p>
            </div>
            
            <!-- Content -->
            <div style="padding: 50px 40px;">
              <h2 style="color: #1a202c; font-size: 28px; font-weight: 600; margin: 0 0 20px 0; text-align: center;">
                🔐 Verification Required
              </h2>
              
              <p style="color: #4a5568; font-size: 16px; line-height: 1.6; margin: 0 0 30px 0; text-align: center;">
                We've sent you this verification code to ensure the security of your account.
              </p>
              
              <!-- OTP Box -->
              <div style="background: linear-gradient(135deg, #f7fafc 0%, #edf2f7 100%); border: 2px dashed #cbd5e0; border-radius: 20px; padding: 40px 20px; text-align: center; margin: 40px 0; box-shadow: 0 10px 25px rgba(0,0,0,0.1);">
                <p style="color: #718096; font-size: 14px; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 1px; font-weight: 500;">
                  Your Verification Code
                </p>
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #ffffff; font-size: 42px; font-weight: 800; letter-spacing: 8px; padding: 20px; border-radius: 15px; box-shadow: 0 8px 20px rgba(102, 126, 234, 0.3); margin: 0 auto; display: inline-block; min-width: 200px;">
                  ${otp}
                </div>
              </div>
              
              <!-- Timer Warning -->
              <div style="background: #fef5e7; border-left: 4px solid #f6ad55; padding: 20px; border-radius: 8px; margin: 30px 0;">
                <p style="color: #c05621; margin: 0; font-size: 15px; font-weight: 500;">
                  ⏰ This code will expire in <strong>5 minutes</strong>
                </p>
              </div>
              
              <p style="color: #718096; font-size: 14px; line-height: 1.6; text-align: center; margin: 30px 0 0 0;">
                If you didn't request this code, please ignore this email or contact our support team.
              </p>
            </div>
            
            <!-- Footer -->
            <div style="background: #f7fafc; padding: 30px 40px; text-align: center; border-top: 1px solid #e2e8f0;">
              <p style="color: #a0aec0; font-size: 13px; margin: 极 0; line-height: 1.5;">
                This is an automated message from <strong>Logigo</strong><br>
                Your trusted logistics partner 🚚
              </p>
            </div>
          </div>
        </body>
        </html>
      `
    });
    return true;
  } catch (error) {
    console.error('Email sending error:', error);
    return false;
  }
};

// Send booking confirmation email with attractive styling
export const sendBookingConfirmation = async (userEmail, bookingDetails) => {
  if (!emailTransport) {
    console.error('Email transporter not available');
    return false;
  }

  const mailOptions = {
    from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
    to: userEmail,
    subject: '🎉 Booking Confirmed - Your Logigo Service is Ready!',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Booking Confirmation</title>
      </head>
      <body style="margin: 0; padding: 极; background-color: #f0f9ff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
        <div style="max-width: 650px; margin: 0 auto; background-color: #ffffff; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #0ea5e9 0%, #3b82f6 50%, #6366f1 100%); padding: 40px 30px; text-align: center; position: relative; overflow: hidden;">
            <div style="position: absolute; top: -50px; right: -50px; width: 100px; height: 100px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
            <div style="position: absolute; bottom: -30px; left: -30px; width: 60px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
            
            <h1 style="color: #ffffff; margin: 0; font-size: 36px; font-weight: 800; letter-spacing: -1px;">
              🚚 LOGIGO
            </h1>
            <p style="极: #e0f2fe; margin: 10px 0 0 0; font-size: 18px; font-weight: 500;">
              Booking Confirmed Successfully!
            </p>
          </div>
          
          <!-- Success Banner -->
          <极 style="background: linear-gradient(90deg, #10b981 0%, #059669 100%); color: #ffffff; text-align: center; padding: 25px;">
            <h2 style="margin: 0; font-size: 28px; font-weight: 700;">
              🎉 Great News!
            </h2>
            <p style="margin: 8px 0 0 0; font-size: 16px; opacity: 0.95;">
              Your vehicle renting Service has been confirmed and is ready to go!
            </p>
          </极>
          
          <!-- Content -->
          <div style="padding: 50px 40px;">
            <p style="color: #374151; font-size: 18px; line-height: 1.6; margin: 0 0 40px 0;">
              Dear Valued Customer,
            </p>
            
            <p style="color: #6b7280; font-size: 16px; line-height: 1.6; margin: 0 0 40px 0;">
              Thank you for choosing Logigo! We're excited to serve you with our premium logistics services. Your booking has been successfully confirmed and our team is already preparing for your service.
            </p>
            
            <!-- Booking Details Card -->
            <div style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border: 1px solid #e2e8f0; border-radius: 20px; padding: 35px; margin: 40px 0; box-shadow: 0 10极 25px rgba(0,0,0,0.08);">
              <h3 style="color: #1e40af; font-size: 24px; font-weight: 700; margin: 0 0 30px 0; text-align: center; border-bottom: 2px solid #dbeafe; padding-bottom: 15px;">
                📋 Booking Details
              </h3>
              
              <div style="display: table; width: 100%; border-spacing: 0;">
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 600; font-size: 15px;">🆔 Booking ID:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; vertical-align: top;">
                    <span style="color: #1f2937; font-weight: 700; font-size: 15px; background: #dbeafe; padding: 4px 12px; border-radius: 20px;">${bookingDetails.bookingId}</span>
                  </div>
                </div>
                
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 极; font-size: 15px;">🚛 Service:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; vertical-align: top;">
                    <span style="color: #1f2937; font-size: 15px;">${bookingDetails.service || 'Premium Vehicle Renting Service'}</span>
                  </div>
                </div>
                
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5极7eb; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 600; font-size: 15px;">📍 Pickup Location:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; vertical-align: top;">
                    <span style="color: #1f2937; font-size: 15px;">${bookingDetails.pickupLocation || 'Will be confirmed shortly'}</span>
                  </div>
                </div>
                
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 600; font-size: 15px;">🎯 Delivery Location:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; vertical-align: top;">
                    <span style="color: #1f2937; font-size: 15px;">${bookingDetails.deliveryLocation || 'Will be confirmed shortly'}</span>
                  </div>
                </div>
                
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 600; font-size: 15px;">📅 Service Date:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; border-bottom: 1px solid #e5e7eb; vertical-align: top;">
                    <span style="color: #1f2937; font-size: 15px;">${new Date(bookingDetails.date || Date.now()).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}</span>
                  </div>
                </div>
                
                <div style="display: table-row;">
                  <div style="display: table-cell; padding: 12px 0; width: 40%; vertical-align: top;">
                    <span style="color: #374151; font-weight: 600; font-size: 15px;">✅ Status:</span>
                  </div>
                  <div style="display: table-cell; padding: 12px 0; vertical-align: top;">
                    <span style="color: #ffffff; background: #10b981; padding: 6px 16px; border-radius: 20px; font-weight: 700; font-size: 14px;">CONFIRMED</span>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Next Steps -->
            <div style="background: #fef3c7; border-left: 4px solid #f59e0b; padding: 25px; border-radius: 8px; margin: 40px 0;">
              <h4 style="color: #92400e; margin: 0 0 15px 0; font-size: 18px; font-weight: 700;">
                📞 What happens next?
              </h4>
              <p style="color: #a16207; margin: 0; font-size: 15px; line-height: 1.6;">
                Our team will contact you within <strong>24 hours</strong> to confirm the details and coordinate the service timing. You'll receive real-time updates via SMS and email.
              </p>
            </div>
            
            <p style="color: #374151; font-size: 16px; line-height: 1.6; text-align: center; margin: 40px 0 0 0;">
              Thank you for trusting <strong>Logigo</strong> with your logistics needs! 🙏
            </p>
          </div>
          
          <!-- Footer -->
          <div style="background: #1f2937; color: #ffffff; padding: 40px; text-align: center;">
            <h3 style="color: #60a5fa; margin: 0 0 15px 0; font-size: 20px; font-weight: 600;">
              Need Help? We're Here! 💬
            </h3>
            <p style="color: #d1d5db; font-size: 14px; margin: 0 0 20px 0; line-height: 1.6;">
              Have questions about your booking? Our support team is available 24/7<br>
              📧 Email: support@logigo.com | 📞 Phone: +91-XXXX-XXXXX
            </p>
            <hr style="border: none; border-top: 1px solid #374151; margin: 20px 0;">
            <p style="color: #9ca3af; font-size: 12px; margin: 0; line-height: 1.4;">
              This is an automated confirmation email from <strong>Logigo</strong><br>
              Your trusted partner for seamless logistics solutions 🚚✨
            </p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    const result = await emailTransport.sendMail(mailOptions);
    console.log('✅ Email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('❌ Email sending failed:', error.message);
    return null;
  }
};

// Send welcome email for new users
export const sendWelcomeEmail = async (userEmail, userName) => {
  if (!emailTransport) {
    console.error('Email transporter not available');
    return false;
  }

  const mailOptions = {
    from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
    to: userEmail,
    subject: '🎉 Welcome to Logigo - Your Logistics Journey Begins!',
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to Logigo</title>
      </head>
      <body style="margin: 0; padding: 0; background-color: #f0fdf4; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">
          <!-- Header -->
          <div style="background: linear-gradient(135deg, #059669 0%, #10b981 50%, #34d399 100%); padding: 40px 30px; text-align: center; position: relative; overflow: hidden;">
            <div style="position: absolute; top: -40px; right: -40px; width: 80px; height: 80px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
            <div style="position: absolute; bottom: -20px; left: -20px; width: 50px; height: 50px; background: rgba(255,255,255,0.1); border-radius: 50%;"></div>
            
            <h1 style="color: #ffffff; margin: 0; font-size: 36px; font-weight: 800; letter-spacing: -1px;">
              🚚 LOGIGO
            </h1>
            <p style="color: #d1fae5; margin: 10px 0 0 0; font-size: 18px; font-weight: 500;">
              Welcome to the Future of Logistics!
            </p>
          </div>
          
          <!-- Welcome Banner -->
          <div style="background: linear-gradient(90deg, #3b82f6 0%, #1d4ed8 100%); color: #ffffff; text-align: center; padding: 30px;">
            <h2 style="margin: 0; font-size: 32px; font-weight: 700;">
              🎉 Welcome Aboard, ${userName}!
            </h2>
            <p style="margin: 10px 0 0 0; font-size: 16px; opacity: 0.95;">
              Your logistics journey starts here
            </p>
          </div>
          
          <!-- Content -->
          <div style="padding: 50px 40px;">
            <p style极="color: #374151; font-size: 18px; line-height: 1.6; margin: 0 0 30px 0; text-align: center;">
              Thank you for joining the <strong>Logigo</strong> family! We're thrilled to have you with us and can't wait to make your logistics experience seamless and efficient.
            </p>
            
            <!-- Features Cards -->
            <div style="margin: 40px 0;">
              <h3 style="color: #1f2937; font-size: 24px; font-weight: 700; text-align: center; margin: 0 0 30px 0;">
                🌟 What You Can Do Now
              </h3>
              
              <!-- Feature 1 -->
              <div style="background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%); border-left: 4px solid #3b82f6; padding: 25px; border-radius: 12px; margin: 20px 0; box-shadow: 0 4px 15px rgba(59, 130, 246, 0.1);">
                <h4 style="color: #1e40af; margin: 0 0 8px 0; font-size: 18px; font-weight: 600;">
                  📦 Book Logistics Services
                </h4>
                <p style="color: #1e40af; margin: 0; font-size: 14px; opacity: 0.8;">
                  Start booking your vehicle rentals and delivery services with just a few clicks
                </p>
              </div>
              
              <!-- Feature 2 -->
              <div style="background: linear-gradient(135deg, #dcfce7 0%, #bbf7d0 100%); border-left: 4px solid #10b981; padding: 25px; border-radius: 12px; margin: 20px 0; box-shadow: 0 4px 15px rgba(16, 185, 129, 0.1);">
                <h4 style="color: #047857; margin: 0 0 8px 0; font-size: 极8px; font-weight: 600;">
                  📱 Real-time Tracking
                </h4>
                <p style="color: #047857; margin: 0; font-size: 14px; opacity: 0.8;">
                  Track your deliveries in real-time and get instant updates on your shipments
                </p>
              </div>
              
              <!-- Feature 3 -->
              <div style="background: linear-gradient(135deg, #fef3c7 0%, #fde68a 极00%); border-left: 4px solid #f59e0b; padding: 25px; border-radius: 12px; margin: 20px 0; box-shadow: 0 4px 15px rgba(245, 158, 11, 0.1);">
                <h4 style="color: #92400e; margin: 0 0 8px 0; font-size: 18px; font-weight: 600;">
                  ⚙️ Manage Your Account
                </h极>
                <p style="color: #92400e; margin: 0; font-size: 14px; opacity: 0.8;">
                  Customize your preferences and manage all your bookings from one dashboard
                </p>
              </div>
            </div>
            
            <!-- CTA Section -->
            <div style="text-align: center; margin: 50px 0;">
              <h3 style="color: #1f2937; font-size: 22px; font-weight: 700; margin: 0 0 20px 0;">
                Ready to Get Started? 🚀
              </h3>
              <p style="color: #6b7280; font-size: 16px; margin: 0 0 30px 0;">
                Your account is all set up and ready to go. Start exploring our services today!
              </p>
            </div>
            
            <!-- Support Info -->
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 25px; border-radius: 12px; text-align: center;">
              <h4 style="color: #374151; margin: 0 0 15px 0; font-size: 18px; font-weight: 600;">
                🤝 Need Any Help?
              </h4>
              <p style="color: #6b7280; font-size: 14px; margin: 0; line-height: 1.6;">
                Our support team is here to help you every step of the way.<br>
                Feel free to reach out anytime at <strong>support@logigo.com</strong>
              </p>
            </div>
          </div>
          
          <!-- Footer -->
          <div style="background: #111827; color: #ffffff; padding: 35px; text-align: center;">
            <h3 style="color: #60a5fa; margin: 0 极 15px 0; font-size: 20px; font-weight: 600;">
              Welcome to the Logigo Family! 🎉
            </h3>
            <p style="color: #d1d5db; font-size: 14px; margin: 0 0 20px 0; line-height: 1.6;">
              Follow us on social media for updates, tips, and exclusive offers!
            </p>
            <hr style="border: none; border-top: 1px solid #374151; margin: 20px 0;">
            <p style="color: #9ca3af; font-size: 12px; margin: 0; line-height: 1.4;">
              This is an automated welcome email from <strong>Logigo</strong><br>
              Making logistics simple, reliable, and efficient 🚚⚡
            </p>
          </div>
        </div>
      </body>
      </html>
    `
  };

  try {
    const result = await emailTransport.sendMail(mailOptions);
    console.log('✅ Welcome email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('❌ Welcome email sending failed:', error.message);
    return null;
  }
};

// Send booking notification email (for admin approval/cancellation)
export const sendBookingNotification = async (email, subject, html) => {
  if (!emailTransport) {
    console.error('Email transporter not available');
    return false;
  }

  const mailOptions = {
    from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
    to: email,
    subject: subject,
    html: html
  };

  try {
    const result = await emailTransport.sendMail(mailOptions);
    console.log('✅ Booking notification email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('❌ Booking notification email sending failed:', error.message);
    return null;
  }
};

// Generic email sending function
export const sendEmail = async ({ to, subject, html }) => {
  if (!emailTransport) {
    console.error('Email transporter not available');
    return false;
  }

  const mailOptions = {
    from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
    to,
    subject,
    html
  };

  try {
    const result = await emailTransport.sendMail(mailOptions);
    console.log('✅ Generic email sent successfully:', result.messageId);
    return result;
  } catch (error) {
    console.error('❌ Generic email sending failed:', error.message);
    return null;
  }
};

// Send payment refund email (using your template)
export const sendPaymentRefundEmail = async (userEmail, refundDetails) => {
  if (!emailTransport) {
    console.error('❌ Email transporter not available. Trying to reinitialize...');
    
    // Dobara initialize karne ki koshish karo
    try {
      const initialized = await initializeEmailService();
      if (!initialized) {
        console.error('❌ Failed to initialize email service');
        return false;
      }
    } catch (error) {
      console.error('❌ Email service reinitialization failed:', error);
      return false;
    }
  }

  // ✅ Check karein ki refundDetails sahi se aa raha hai
  if (!refundDetails) {
    console.error('❌ Refund details are missing');
    return false;
  }

  // ✅ Default values set karein agar koi property missing hai
  const safeRefundDetails = {
    userName: refundDetails.userName || 'Customer',
    bookingId: refundDetails.bookingId || 'N/A',
    vehicleName: refundDetails.vehicleName || 'Vehicle',
    amount: refundDetails.amount || 0,
    refundDate: refundDetails.refundDate || new Date(),
    paymentMethod: refundDetails.paymentMethod || 'Payment Method'
  };

  const mailOptions = {
    from: process.env.GMAIL_USER || HARDCODED_CONFIG.GMAIL_USER,
    to: userEmail,
    subject: '🔄 Payment Refund Processed - Logigo',
    html: paymentRefundedTemplate(
      safeRefundDetails.userName,
      safeRefundDetails.bookingId,
      safeRefundDetails.vehicleName,
      safeRefundDetails.amount,
      safeRefundDetails.refundDate,
      safeRefundDetails.paymentMethod
    )
  };

  try {
    const result = await emailTransport.sendMail(mailOptions);
    console.log('✅ Refund email sent successfully to:', userEmail);
    return true;
  } catch (error) {
    console.error('❌ Refund email failed:', error.message);
    return false;
  }
};
// Exports
export default {
  sendOtpEmail,
  sendBookingConfirmation,
  sendBookingNotification,
  sendEmail,
  initializeEmailService,
  testEmailConnection,
  isEmailServiceAvailable
};