import jwt from "jsonwebtoken";
import User from "../models/User.js";

/**
 * verifyAdminToken:
 * - In production: verifies JWT and checks user.role === 'admin'
 * - For local dev/test: set ADMIN_BYPASS=true in .env to skip auth (only for dev!)
 */
export const verifyAdminToken = async (req, res, next) => {
  try {
    // Development bypass (ONLY use locally)
    if (process.env.ADMIN_BYPASS === "true") {
      return next();
    }

    const auth = req.headers.authorization;
    if (!auth || !auth.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Missing token" });
    }
    const token = auth.replace("Bearer ", "");
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded?.id) return res.status(401).json({ message: "Invalid token" });

    const user = await User.findById(decoded.id).lean();
    if (!user || user.role !== "admin") {
      return res.status(403).json({ message: "Admin access only" });
    }

    req.admin = user;
    next();
  } catch (err) {
    console.error("verifyAdminToken:", err.message);
    res.status(401).json({ message: "Authentication failed", error: err.message });
  }
};
