// src/middleware/payment.middleware.js
import  Payment  from '../models/Payment.js';

export const validatePayment = (req, res, next) => {
  const { bookingId, amount, paymentMethod, vehicleName, timestamp } = req.body;
  
  // Check for required fields
  if (!bookingId || !amount || !paymentMethod || !vehicleName || !timestamp) {
    return res.status(400).json({
      success: false,
      message: 'Missing required fields: bookingId, amount, paymentMethod, vehicleName, timestamp'
    });
  }
  
  // Validate amount
  if (typeof amount !== 'number' || amount <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Amount must be a positive number'
    });
  }
  
  // Validate payment method
  const validPaymentMethods = ['credit_card', 'debit_card', 'upi', 'net_banking', 'wallet', 'cash'];
  if (!validPaymentMethods.includes(paymentMethod)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid payment method. Must be one of: ' + validPaymentMethods.join(', ')
    });
  }
  
  // Validate timestamp
  if (isNaN(Date.parse(timestamp))) {
    return res.status(400).json({
      success: false,
      message: 'Invalid timestamp format'
    });
  }
  
  next();
};

export const validatePaymentId = (req, res, next) => {
  const { paymentId } = req.params;
  
  // Validate payment ID format (starts with PAY followed by alphanumeric characters)
  if (!paymentId || !/^PAY[A-Z0-9]+$/.test(paymentId)) {
    return res.status(400).json({
      success: false,
      message: 'Invalid payment ID format'
    });
  }
  
  next();
};

export const initiatePayment = async (req, res, next) => {
  try {
    const { bookingId, amount, paymentMethod } = req.body;
    
    // Check if payment already exists for this booking
    const existingPayment = await Payment.findOne({ bookingId });
    if (existingPayment) {
      return res.status(400).json({
        success: false,
        message: 'Payment already exists for this booking',
        paymentId: existingPayment.paymentId
      });
    }
    
    // Simulate payment gateway processing
    const paymentResult = await simulatePaymentGateway(amount, paymentMethod);
    
    if (paymentResult.success) {
      // Add payment result to request object for use in the route
      req.paymentGatewayResponse = paymentResult;
      next();
    } else {
      return res.status(400).json({
        success: false,
        message: 'Payment initiation failed',
        reason: paymentResult.message
      });
    }
  } catch (error) {
    console.error('Error initiating payment:', error);
    return res.status(500).json({
      success: false,
      message: 'Error initiating payment'
    });
  }
};

export const getPaymentStatus = async (req, res, next) => {
  try {
    const { paymentId } = req.params;
    
    // Find payment in database
    const payment = await Payment.findOne({ paymentId });
    
    if (!payment) {
      return res.status(404).json({
        success: false,
        message: 'Payment not found'
      });
    }
    
    // Add payment details to request object
    req.paymentDetails = payment;
    
    // For simulated payment status checking
    const statusCheck = await checkPaymentStatusWithGateway(paymentId);
    
    // Update payment status if different
    if (payment.status !== statusCheck.status) {
      payment.status = statusCheck.status;
      await payment.save();
    }
    
    next();
  } catch (error) {
    console.error('Error checking payment status:', error);
    return res.status(500).json({
      success: false,
      message: 'Error checking payment status'
    });
  }
};

// Helper function to simulate payment gateway processing
const simulatePaymentGateway = async (amount, paymentMethod) => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // Simulate different outcomes based on payment method and amount
  const successRate = {
    'credit_card': 0.95,
    'debit_card': 0.90,
    'upi': 0.98,
    'net_banking': 0.85,
    'wallet': 0.99,
    'cash': 1.0
  };
  
  const isSuccess = Math.random() < successRate[paymentMethod];
  
  if (isSuccess) {
    return {
      success: true,
      transactionId: 'TXN' + Date.now().toString(36).toUpperCase(),
      message: 'Payment processed successfully'
    };
  } else {
    return {
      success: false,
      message: 'Payment declined by bank'
    };
  }
};

// Helper function to simulate payment status checking with gateway
const checkPaymentStatusWithGateway = async (paymentId) => {
  // Simulate API call delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Simulate different statuses
  const statuses = ['success', 'pending', 'failed', 'refunded'];
  const weights = [0.7, 0.1, 0.15, 0.05]; // Probability weights
  
  let random = Math.random();
  let statusIndex = 0;
  let weightSum = 0;
  
  for (let i = 0; i < weights.length; i++) {
    weightSum += weights[i];
    if (random <= weightSum) {
      statusIndex = i;
      break;
    }
  }
  
  return {
    status: statuses[statusIndex],
    checkedAt: new Date()
  };
};

// Export individual functions
export default {
  validatePayment,
  validatePaymentId,
  initiatePayment,
  getPaymentStatus
};

