// Simple validation middleware
export const validateBooking = (req, res, next) => {
  const requiredFields = [
    'vehicleId', 'vehicleName', 'ratePerDay', 'days', 'total',
    'customer.fullName', 'customer.phone', 'customer.email', 'customer.license',
    'trip.pickupLocation', 'trip.dropoffLocation', 'trip.pickupDT', 'trip.dropoffDT',
    'paymentMethod'
  ];

  const missingFields = [];

  requiredFields.forEach(field => {
    const value = field.split('.').reduce((obj, key) => obj && obj[key], req.body);
    if (value === undefined || value === null || value === '') {
      missingFields.push(field);
    }
  });

  if (missingFields.length > 0) {
    return res.status(400).json({
      success: false,
      message: 'Missing required fields',
      missingFields: missingFields
    });
  }

  next();
};

// Error handling middleware
export const errorHandler = (err, req, res, next) => {
  console.error('Error:', err);
  
  if (err.name === 'ValidationError') {
    return res.status(400).json({
      success: false,
      message: 'Validation Error - Please check your input data'
    });
  }

  res.status(500).json({
    success: false,
    message: 'Internal server error'
  });
};