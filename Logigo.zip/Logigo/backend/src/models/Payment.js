// models/Payment.js - TEMPORARY FIX
import mongoose from 'mongoose';

const paymentSchema = new mongoose.Schema({
  paymentId: { 
    type: String, 
    required: true, 
    unique: true 
  },
  bookingId: { 
    type: String, 
    required: true 
  },
  amount: { 
    type: Number, 
    required: true 
  },
  paymentMethod: { 
    type: String, 
    required: true 
  },
  vehicleName: { 
    type: String, 
    required: true 
  },
  timestamp: { 
    type: Date, 
    required: true 
  },
  status: { 
    type: String, 
    default: 'pending',
    enum: ['pending', 'success', 'failed', 'refunded']
  },
  transactionId: { 
    type: String 
  },
  userEmail: {
    type: String,
    required: true
  },
  userName: {
    type: String,
    required: false
  },
  // ✅ TEMPORARY FIX: UTR ko optional bana de
  utrNumber: {
    type: String,
    required: false, // TEMPORARY: false kardia
    unique: false   // TEMPORARY: false kardia
  },
  refundStatus: {
    type: String,
    enum: ['pending', 'refunded', 'failed', null],
    default: null
  },
  refundDate: {
    type: Date,
    default: null
  },
  refundId: {
    type: String,
    default: null
  }
}, { 
  timestamps: true 
});

paymentSchema.index({ userEmail: 1 });
paymentSchema.index({ bookingId: 1 });
paymentSchema.index({ timestamp: -1 });

const Payment = mongoose.model('Payment', paymentSchema);
export default Payment;