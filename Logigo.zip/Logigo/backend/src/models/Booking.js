// src/models/Booking.js
import mongoose from "mongoose";

const bookingSchema = new mongoose.Schema({
  bookingId: {
    type: String,
    unique: true,
    required: true
  },
  vehicleId: {
    type: String,
    required: false
  },
  vehicleName: {
    type: String,
    required: true
  },
  ratePerDay: {
    type: Number,
    required: true
  },
  days: {
    type: Number,
    required: true
  },
  total: {
    type: Number,
    required: true
  },
  customer: {
    fullName: {
      type: String,
      required: true
    },
    phone: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    },
    license: {
      type: String,
      required: true
    }
  },
  trip: {
    pickupLocation: {
      type: String,
      required: true
    },
    dropoffLocation: {
      type: String,
      required: true
    },
    pickupDT: {
      type: Date,
      required: true
    },
    dropoffDT: {
      type: Date,
      required: true
    }
  },
  paymentMethod: {
    type: String,
    required: true
  },
  notes: {
    type: String,
    default: ""
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'cancelled', 'completed'],
    default: "pending",
    lowercase: true
  }
}, {
  timestamps: true
});

// Generate booking ID before saving
bookingSchema.pre("save", function(next) {
  if (this.isNew && !this.bookingId) {
    this.bookingId = "BK" + Date.now();
  }
  next();
});

export default mongoose.model("Booking", bookingSchema);