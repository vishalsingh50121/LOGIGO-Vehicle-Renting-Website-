document.addEventListener("DOMContentLoaded", () => {
  const navbarLinks = document.getElementById("navbarLinks");
  const token = localStorage.getItem("token") || sessionStorage.getItem("token");
  const user = JSON.parse(localStorage.getItem("user")) || null;

  if (token && user) {
    // ✅ Avatar or Initials
    let avatarHTML;
    if (user.avatar) {
      avatarHTML = `<img src="${user.avatar}" alt="Avatar" 
        class="rounded-circle border" style="width:32px;height:32px;object-fit:cover;">`;
    } else {
      const initials = user.name ? user.name.charAt(0).toUpperCase() : "U";
      avatarHTML = `<div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center border"
        style="width:32px;height:32px;font-size:14px;">${initials}</div>`;
    }

    navbarLinks.innerHTML = `
      <li class="nav-item d-flex align-items-center me-2">
        ${avatarHTML}
        <span class="nav-link text-light fw-semibold ms-2">Hi, ${user.name || "User"}</span>
      </li>
      <li class="nav-item"><a class="nav-link" href="booking.html">Book Ride</a></li>
      <li class="nav-item"><a class="nav-link" href="userDashboard.html">My Bookings</a></li>
      <li class="nav-item">
        <a class="nav-link text-danger fw-bold logout-link" href="#" id="logoutBtn">
          <i class="fas fa-sign-out-alt"></i> Logout
        </a>
      </li>
    `;

    document.getElementById("logoutBtn").addEventListener("click", () => {
      localStorage.removeItem("token");
      sessionStorage.removeItem("token");
      localStorage.removeItem("user");
      window.location.href = "userLogin.html";
    });

  } else {
    // ❌ Not Logged In
    navbarLinks.innerHTML = `
      <li class="nav-item"><a class="nav-link" href="userLogin.html">Login</a></li>
      <li class="nav-item"><a class="nav-link" href="signup.html">Signup</a></li>
    `;
  }
});
